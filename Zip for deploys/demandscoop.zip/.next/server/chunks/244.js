exports.id = 244;
exports.ids = [244];
exports.modules = {

/***/ 2906:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__myFont_3711e5', '__myFont_Fallback_3711e5'"},
	"className": "__className_3711e5"
};


/***/ }),

/***/ 244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   e: () => (/* binding */ AboutSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_font_local_target_css_path_Components_AboutSection_AboutSection_js_import_arguments_src_Fonts_Montserrat_Medium_ttf_variableName_myFont___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2906);
/* harmony import */ var next_font_local_target_css_path_Components_AboutSection_AboutSection_js_import_arguments_src_Fonts_Montserrat_Medium_ttf_variableName_myFont___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_local_target_css_path_Components_AboutSection_AboutSection_js_import_arguments_src_Fonts_Montserrat_Medium_ttf_variableName_myFont___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




const AboutSection = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "displayflexat-ns with-backgrnd-blck",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "widtgh-fr-dms-center-layout",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "display-flx-with-about-dems-andblx",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flx-in-of-hder-and-line",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "about-hdr-at-in-jka",
                                children: "About Demandscoop"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "line-btwn-about-and-dhdr"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "width-for-left-section-at-sjk",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "hdr-aof-htwo-tag-at-about-sec",
                                children: "Engaging More, Refreshing Result"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "para-at-about-sec-of-home-paly",
                                children: "The search for quality leads is never-ending, but with the right solutions, your business can reach the pinnacle of success."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "para-at-about-sec-of-home-paly",
                                children: "With our 20+ years of rich experience, DemandScoop bridges the gap between the demand for quality leads and delivering the best leads to your enterprise. Our experience in the B2B arena has helped us collaborate with clients and deliver high-quality data, metrics, and analytics that drives value and satisfaction. DemandScoop goes the distance in giving its clients what they rightly deserve—unparalleled and sales-focused services."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/Contactus",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    // className="lets-cnt-btn-at-main-layout"
                                    style: (next_font_local_target_css_path_Components_AboutSection_AboutSection_js_import_arguments_src_Fonts_Montserrat_Medium_ttf_variableName_myFont___WEBPACK_IMPORTED_MODULE_3___default().style),
                                    className: "contac-us-page-btn-cta-sjm margin-noleft",
                                    children: "Lets Connect"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "display-block-btns-of-call-back-and-contact padobjdsosdv-sk",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/Contactus",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        style: (next_font_local_target_css_path_Components_AboutSection_AboutSection_js_import_arguments_src_Fonts_Montserrat_Medium_ttf_variableName_myFont___WEBPACK_IMPORTED_MODULE_3___default().style),
                                        // className="lets-cnt-btn-at-main-layout"
                                        className: "lets-connect-atmobile-view-sect",
                                        children: "Lets Connect"
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ })

};
;