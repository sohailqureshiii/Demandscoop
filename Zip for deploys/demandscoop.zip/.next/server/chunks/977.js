exports.id = 977;
exports.ids = [977];
exports.modules = {

/***/ 6627:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__myFont_3711e5', '__myFont_Fallback_3711e5'"},
	"className": "__className_3711e5"
};


/***/ }),

/***/ 4977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ ContactusForm_ContactUsForm)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/font/local/target.css?{"path":"Components\\ContactusForm\\ContactUsForm.js","import":"","arguments":[{"src":"../../Fonts/Montserrat-Medium.ttf"}],"variableName":"myFont"}
var Montserrat_Medium_ttf_variableName_myFont_ = __webpack_require__(6627);
var Montserrat_Medium_ttf_variableName_myFont_default = /*#__PURE__*/__webpack_require__.n(Montserrat_Medium_ttf_variableName_myFont_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./Components/Input/Input.js


const Input = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("p", {
                className: "title-for-input-atha",
                children: props.title
            }),
            /*#__PURE__*/ jsx_runtime.jsx("input", {
                className: "Input-for-contact-andother-compo",
                type: "text",
                placeholder: props.placeholder
            })
        ]
    });
};

;// CONCATENATED MODULE: ./Components/ContactusForm/ContactUsForm.js




const ContactUsForm = ()=>{
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "container-for-contact-us-form",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("h2", {
                    className: "header-for-contact-us-form",
                    children: "Send us a message"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "continer-of-inputs-at-contact-us-form",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "container-for-inputs",
                            children: /*#__PURE__*/ jsx_runtime.jsx(Input, {
                                title: "How can we best help you today",
                                placeholder: "Choose one"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "container-for-inputs",
                            children: /*#__PURE__*/ jsx_runtime.jsx(Input, {
                                title: "Full Name",
                                placeholder: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "container-for-inputs",
                            children: /*#__PURE__*/ jsx_runtime.jsx(Input, {
                                title: "Bussiness Email",
                                placeholder: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "container-for-inputs",
                            children: /*#__PURE__*/ jsx_runtime.jsx(Input, {
                                title: "Phone Number",
                                placeholder: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "container-for-inputs",
                            children: /*#__PURE__*/ jsx_runtime.jsx(Input, {
                                title: "Job Title",
                                placeholder: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("button", {
                            style: (Montserrat_Medium_ttf_variableName_myFont_default()).style,
                            className: "btn-for-submit-at-contact-screen",
                            children: "Submit"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                            className: "terms-and-privacy-text-ahdjsn",
                            children: [
                                "By submitting this form, you are agreeing to Demandscoop's",
                                /*#__PURE__*/ jsx_runtime.jsx("br", {}),
                                " Privacy Policy and Terms of Service."
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const ContactusForm_ContactUsForm = (ContactUsForm);


/***/ })

};
;