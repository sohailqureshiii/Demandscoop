import React from "react";
import Clientone from "../../public/adobe.svg";
import Clientwo from "../../public/okta.svg";
import Clienthree from "../../public/loom.svg";
import Clientfour from "../../public/hashicorp.svg";
export const Slider = () => {
  return (
    <div className="displayflexat-ns">
      <div className="paddinglow-atsdj margin-btm-at-mobview">
        <p
          // className="trusted-para-at-hm-main-layout"
          className="trust-partner-list-at-home-layout"
        >
          TRUSTED BY 30,000+ BUSINESSES.
        </p>
      </div>
    </div>
  );
};
