"use strict";
exports.id = 115;
exports.ids = [115];
exports.modules = {

/***/ 5693:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/DemandscoopMain-logo.3cbc1ba1.png","height":757,"width":2738,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAD1BMVEX///////////////////+Rd1MVAAAABXRSTlMlHzpTK9fmdp0AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAYSURBVHicBcEBAQAACAIg1P5vDnQ4aEI8AK8AD+5JvB0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 4608:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo-demand.50207d1e.jpeg","height":1080,"width":1080,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAf/xAAeEAABAwQDAAAAAAAAAAAAAAABAAIDBAYRMQUSIf/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCZyVFvm0oYGUkw5pspL5wT0czJ37jWNBERB//Z","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_logo_demand_jpeg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4608);



3;

const Footer = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "footer-background",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flx-for-ftr-bc",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "header-layout-at-main-section flx-in-four-comlumas",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "box-fr-",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: _public_logo_demand_jpeg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                    width: 150,
                                    height: 150,
                                    alt: "Picture of the author"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "pad-top-fr-match-logo",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "service-header-at-footer-section",
                                        children: "Services"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "secound-her-hthree-hdr-at-footer",
                                        children: "Sales Services"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "Appointment Generation"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "BANT Leads"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "Account Based Marketing"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "SQL - Sales Qualified Leads"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "MQL - Marketing Qualified Leads"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "B2B Demand Generation"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "pad-top-fr-match-logo",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "service-header-at-footer-section",
                                        children: "Resources"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: "White Paper"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "E-Books"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "pad-top-fr-match-logo",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "service-header-at-footer-section",
                                        children: "Contact Us"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: [
                                            " ",
                                            "info@demandscoop.com"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "services-and-other-kinks-at-footer",
                                        children: [
                                            "DemandScoop Pvt. Ltd.",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            " 444 Alaska Avenue Suite #BPN742 Torrance,",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            "CA 90503 USA"
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "footer-background flx-cntrkjsj",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "black-bkrnd-for-foooter",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "line-htnsk",
                                children: " "
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flx-fr-faq-questionand-plus",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-for-footer-bottom-at",
                                        children: "United States (English)"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-for-footer-bottom-at",
                                        children: "+"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "line-htnsk",
                                children: " "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "end-text-for-website-deamnd",
                                children: "\xa9 2022 DemandScoop - B2B marketing agency created and manged by B2B Digital Marketing"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ HomePageNavbar)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/font/local/target.css?{"path":"Components\\Navbar\\HomePageNavbar.js","import":"","arguments":[{"src":"../../Fonts/Montserrat-Medium.ttf"}],"variableName":"myFont"}
var Montserrat_Medium_ttf_variableName_myFont_ = __webpack_require__(4077);
var Montserrat_Medium_ttf_variableName_myFont_default = /*#__PURE__*/__webpack_require__.n(Montserrat_Medium_ttf_variableName_myFont_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./public/DemandscoopMain-logo.png
var DemandscoopMain_logo = __webpack_require__(5693);
;// CONCATENATED MODULE: ./public/hamburgerig.png
/* harmony default export */ const hamburgerig = ({"src":"/_next/static/media/hamburgerig.38369552.png","height":33,"width":44,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAD1BMVEX///////9MaXH////////RWIOUAAAABXRSTlOOVgA1GJOGAtwAAAAJcEhZcwAACxMAAAsTAQCanBgAAAAaSURBVHicY2BiZoAAJihgYIQCBAMuxQJVCwAGbAA6lwDy/QAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./Components/NavBarModal/NavBarModal.js





const NavModal = (props)=>{
    if (!props.visible) {
        return null;
    }
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "modalFixedBg",
            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                style: {
                    position: "relative"
                },
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "Container-of-mobile-navigationbar",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flx-in-logo-and-links-of-pages",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: DemandscoopMain_logo/* default */.Z,
                                        width: "100%",
                                        height: 65
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    style: {
                                        padding: "15px"
                                    },
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                                        onClick: props.onClose,
                                        version: "1.0",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "20px",
                                        height: "20px",
                                        viewBox: "0 0 512.000000 512.000000",
                                        preserveAspectRatio: "xMidYMid meet",
                                        style: {
                                            cursor: "pointer"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("metadata", {
                                                children: "Created by potrace 1.16, written by Peter Selinger 2001-2019"
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("g", {
                                                transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
                                                fill: "#fff",
                                                stroke: "none",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                    d: "M445 5089 c-229 -27 -406 -215 -422 -449 -7 -94 9 -171 52 -258 31   -61 111 -144 910 -942 l875 -875 -884 -885 c-926 -928 -924 -926 -960 -1049   -22 -76 -21 -213 3 -290 47 -151 157 -257 308 -296 72 -19 241 -19 309 -1 128   34 115 22 1044 951 l875 875 880 -879 c929 -928 907 -908 1036 -945 77 -23   240 -23 316 -1 203 58 333 235 333 454 0 108 -25 196 -76 273 -20 29 -430 445   -912 925 l-877 871 876 879 c829 831 877 881 904 943 83 190 43 411 -99 550   -110 108 -208 145 -369 138 -122 -6 -189 -29 -274 -93 -32 -24 -436 -422 -897   -884 l-840 -840 -873 869 c-620 617 -888 877 -926 898 -92 53 -201 74 -312 61z"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "pad-at-navigatoio-bxds",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "links-for-mobile-view-innavbar-modla brdr-tp-adk",
                                        children: "Home"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/About",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "links-for-mobile-view-innavbar-modla",
                                        children: "Why Us"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                    className: "links-for-mobile-view-innavbar-modla",
                                    children: "Services"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                    className: "header-at-drp-dwn-at-navbar white-clroisj",
                                    style: {
                                        paddingTop: "15px"
                                    },
                                    children: "Demand Generation"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Service",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "list-of-under-services-at-dropdwn",
                                        children: "Account Based Marketing"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Service",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "list-of-under-services-at-dropdwn",
                                        children: "Content Marketing"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Service",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "list-of-under-services-at-dropdwn",
                                        children: "Event Promotion"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Service",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "list-of-under-services-at-dropdwn",
                                        children: "Marketing Qualified Lead (MQL)"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                            className: "header-at-drp-dwn-at-navbar white-clroisj",
                                            children: "Sales Development"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Appointment Generation"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "BANT Lead"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Confirmed Call Back"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Sales Qualified Lead"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                            className: "header-at-drp-dwn-at-navbar white-clroisj",
                                            children: "Database Services"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "B2B List Building"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Database Cleansing"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Install Database"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                            className: "header-at-drp-dwn-at-navbar white-clroisj",
                                            children: "Digital Marketing"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Email Marketing"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "Market Research"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Service",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "list-of-under-services-at-dropdwn",
                                                children: "SEO Services"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/WhitePapers",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "links-for-mobile-view-innavbar-modla",
                                        children: "WhitePapers"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Contactus",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "links-for-mobile-view-innavbar-modla",
                                        children: "Contact US"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "pad-at-navigatoio-bxds",
                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/Contactus",
                                children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                    // className="lets-cnt-btn-at-main-layout"
                                    className: "lets-connect-atmobile-view-sect",
                                    children: "Lets Connect"
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const NavBarModal = (NavModal);

;// CONCATENATED MODULE: ./Components/DropdownService/DropdownService.js


const DropdownMenu = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "headerDropdownContainer",
        children: [
            props.menu,
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "dropdown",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "upArrowContainer",
                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "upArrow"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "dropdownMenu",
                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "headerDropdownMenu",
                            children: props.children
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const DropdownService = (DropdownMenu);

;// CONCATENATED MODULE: ./Components/Navbar/HomePageNavbar.js










const HomeNavabr = ()=>{
    const [show, setShow] = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "background-for-home-navigationbar",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "layout-box-fr-navigation-sub-bx",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "layout-box-fr-logo-in-jdwla",
                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: DemandscoopMain_logo/* default */.Z,
                                    width: "100%",
                                    height: 65
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                            className: "ul-list-for-navtion-at-home-screen-ajk",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: router.pathname == "/" ? "nav-tabs-links-at-Homescreen" : "Inactive-nav-tabs-links-at-Homescreen",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "/",
                                        children: " Home"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: router.pathname == "/About" ? "nav-tabs-links-at-Homescreen" : "Inactive-nav-tabs-links-at-Homescreen",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "/About",
                                        children: " Why Us"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: "Inactive-nav-tabs-links-at-Homescreen",
                                    children: /*#__PURE__*/ jsx_runtime.jsx(DropdownService, {
                                        menu: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/Contactus",
                                            children: "Services"
                                        }),
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "internal-box-for-drop-down-in-navbar",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                            className: "header-at-drp-dwn-at-navbar",
                                                            children: "Demand Generation"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Account Based Marketing"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Content Marketing"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Event Promotion"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Marketing Qualified Lead (MQL)"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                            className: "header-at-drp-dwn-at-navbar",
                                                            children: "Sales Development"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Appointment Generation"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "BANT Lead"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Confirmed Call Back"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Sales Qualified Lead"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                            className: "header-at-drp-dwn-at-navbar",
                                                            children: "Database Services"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "B2B List Building"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Database Cleansing"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Install Database"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                            className: "header-at-drp-dwn-at-navbar",
                                                            children: "Digital Marketing"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Email Marketing"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "Market Research"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                            href: "/Service",
                                                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                className: "list-of-under-services-at-dropdwn",
                                                                children: "SEO Services"
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: router.pathname == "/WhitePapers" ? "nav-tabs-links-at-Homescreen" : "Inactive-nav-tabs-links-at-Homescreen",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "/WhitePapers",
                                        children: "WhitePapers"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                    className: router.pathname == "/Contactus" ? "nav-tabs-links-at-Homescreen" : "Inactive-nav-tabs-links-at-Homescreen",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: "/Contactus",
                                        children: "Contact US"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/Contactus",
                            children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                className: "btn-at-homepage-navbar-jsd",
                                style: (Montserrat_Medium_ttf_variableName_myFont_default()).style,
                                children: "Get Started"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "display-none-at-hamburger-iohs",
                            onClick: ()=>setShow(true),
                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: hamburgerig,
                                width: 25,
                                height: 25
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx(NavBarModal, {
                visible: show,
                onClose: ()=>setShow(false)
            })
        ]
    });
};
/* harmony default export */ const HomePageNavbar = (HomeNavabr);


/***/ })

};
;