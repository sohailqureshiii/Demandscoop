"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/contact";
exports.ids = ["pages/api/contact"];
exports.modules = {

/***/ "nodemailer":
/*!*****************************!*\
  !*** external "nodemailer" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ "(api)/./pages/api/contact.js":
/*!******************************!*\
  !*** ./pages/api/contact.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! nodemailer */ \"nodemailer\");\n/* harmony import */ var nodemailer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nodemailer__WEBPACK_IMPORTED_MODULE_0__);\n\nconst email = \"rahul23.exam@gmail.com\";\nconst pass = \"xuyfcvfanpynqbhl\";\nconst handler = async (req, res)=>{\n    console.log(\"requestd\");\n    if (req.method === \"POST\") {\n        const data = req.body;\n        // if (!data || !data.name || !data.email || !data.subject || !data.message) {\n        //     return res.status(400).send({ message: \"Bad request\" });\n        // }\n        try {\n            let transporter = nodemailer__WEBPACK_IMPORTED_MODULE_0___default().createTransport({\n                service: \"gmail\",\n                auth: {\n                    user: email,\n                    pass\n                }\n            });\n            // send mail with defined transport object\n            let info = await transporter.sendMail({\n                from: `\"Company Name\" <${email}>`,\n                to: \"rahulc2303@gmail.com\",\n                subject: \"OTP\",\n                html: `\r\n                <div>  \r\n                   <div style=\"margin-top: 50px\">\r\n                    message:${data.message}\r\n                  </div>\r\n                </div>\r\n    \r\n                `\n            });\n            return res.status(200).json({\n                success: true\n            });\n        } catch (err) {\n            console.log(err);\n            return res.status(400).json({\n                message: err.message\n            });\n        }\n    }\n    return res.status(400).json({\n        message: \"Bad request\"\n    });\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvY29udGFjdC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBbUM7QUFFbkMsTUFBTUMsUUFBUTtBQUNkLE1BQU1DLE9BQU87QUFLYixNQUFNQyxVQUFVLE9BQU9DLEtBQUtDO0lBQ3hCQyxRQUFRQyxJQUFJO0lBQ1osSUFBSUgsSUFBSUksV0FBVyxRQUFRO1FBQ3ZCLE1BQU1DLE9BQU9MLElBQUlNO1FBQ2pCLDhFQUE4RTtRQUM5RSwrREFBK0Q7UUFDL0QsSUFBSTtRQUVKLElBQUk7WUFDQSxJQUFJQyxjQUFjWCxpRUFBMEJZLENBQUM7Z0JBQ3pDQyxTQUFTO2dCQUNUQyxNQUFNO29CQUNGQyxNQUFNZDtvQkFDTkM7Z0JBQ0o7WUFDSjtZQUVBLDBDQUEwQztZQUMxQyxJQUFJYyxPQUFPLE1BQU1MLFlBQVlNLFNBQVM7Z0JBQ2xDQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUVqQixNQUFNLENBQUMsQ0FBQztnQkFDakNrQixJQUFJO2dCQUNKQyxTQUFTO2dCQUNUQyxNQUFNLENBQUM7Ozs0QkFHSyxFQUFFWixLQUFLYSxRQUFROzs7O2dCQUkzQixDQUFDO1lBQ0w7WUFFQSxPQUFPakIsSUFBSWtCLE9BQU8sS0FBS0MsS0FBSztnQkFBRUMsU0FBUztZQUFLO1FBQ2hELEVBQUUsT0FBT0MsS0FBSztZQUNWcEIsUUFBUUMsSUFBSW1CO1lBQ1osT0FBT3JCLElBQUlrQixPQUFPLEtBQUtDLEtBQUs7Z0JBQUVGLFNBQVNJLElBQUlKO1lBQVE7UUFDdkQ7SUFDSjtJQUNBLE9BQU9qQixJQUFJa0IsT0FBTyxLQUFLQyxLQUFLO1FBQUVGLFNBQVM7SUFBYztBQUN6RDtBQUNBLGlFQUFlbkIsT0FBT0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2RlbWFuZHNjb29wLy4vcGFnZXMvYXBpL2NvbnRhY3QuanM/MzQ5MyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbm9kZW1haWxlciBmcm9tICdub2RlbWFpbGVyJ1xyXG5cclxuY29uc3QgZW1haWwgPSBcInJhaHVsMjMuZXhhbUBnbWFpbC5jb21cIlxyXG5jb25zdCBwYXNzID0gXCJ4dXlmY3ZmYW5weW5xYmhsXCJcclxuXHJcblxyXG5cclxuXHJcbmNvbnN0IGhhbmRsZXIgPSBhc3luYyAocmVxLCByZXMpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwicmVxdWVzdGRcIilcclxuICAgIGlmIChyZXEubWV0aG9kID09PSBcIlBPU1RcIikge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXEuYm9keTtcclxuICAgICAgICAvLyBpZiAoIWRhdGEgfHwgIWRhdGEubmFtZSB8fCAhZGF0YS5lbWFpbCB8fCAhZGF0YS5zdWJqZWN0IHx8ICFkYXRhLm1lc3NhZ2UpIHtcclxuICAgICAgICAvLyAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5zZW5kKHsgbWVzc2FnZTogXCJCYWQgcmVxdWVzdFwiIH0pO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHRyYW5zcG9ydGVyID0gbm9kZW1haWxlci5jcmVhdGVUcmFuc3BvcnQoe1xyXG4gICAgICAgICAgICAgICAgc2VydmljZTogJ2dtYWlsJyxcclxuICAgICAgICAgICAgICAgIGF1dGg6IHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyOiBlbWFpbCwgLy8gZ2VuZXJhdGVkIGV0aGVyZWFsIHVzZXJcclxuICAgICAgICAgICAgICAgICAgICBwYXNzIC8vIGdlbmVyYXRlZCBldGhlcmVhbCBwYXNzd29yZFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAvLyBzZW5kIG1haWwgd2l0aCBkZWZpbmVkIHRyYW5zcG9ydCBvYmplY3RcclxuICAgICAgICAgICAgbGV0IGluZm8gPSBhd2FpdCB0cmFuc3BvcnRlci5zZW5kTWFpbCh7XHJcbiAgICAgICAgICAgICAgICBmcm9tOiBgXCJDb21wYW55IE5hbWVcIiA8JHtlbWFpbH0+YCwgLy8gc2VuZGVyIGFkZHJlc3NcclxuICAgICAgICAgICAgICAgIHRvOiBcInJhaHVsYzIzMDNAZ21haWwuY29tXCIsIC8vIGxpc3Qgb2YgcmVjZWl2ZXJzXHJcbiAgICAgICAgICAgICAgICBzdWJqZWN0OiBcIk9UUFwiLCAvLyBTdWJqZWN0IGxpbmVcclxuICAgICAgICAgICAgICAgIGh0bWw6IGBcclxuICAgICAgICAgICAgICAgIDxkaXY+ICBcclxuICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJtYXJnaW4tdG9wOiA1MHB4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZToke2RhdGEubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgIFxyXG4gICAgICAgICAgICAgICAgYCxcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cygyMDApLmpzb24oeyBzdWNjZXNzOiB0cnVlIH0pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyBtZXNzYWdlOiBlcnIubWVzc2FnZSB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyBtZXNzYWdlOiBcIkJhZCByZXF1ZXN0XCIgfSk7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IGhhbmRsZXI7Il0sIm5hbWVzIjpbIm5vZGVtYWlsZXIiLCJlbWFpbCIsInBhc3MiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiY29uc29sZSIsImxvZyIsIm1ldGhvZCIsImRhdGEiLCJib2R5IiwidHJhbnNwb3J0ZXIiLCJjcmVhdGVUcmFuc3BvcnQiLCJzZXJ2aWNlIiwiYXV0aCIsInVzZXIiLCJpbmZvIiwic2VuZE1haWwiLCJmcm9tIiwidG8iLCJzdWJqZWN0IiwiaHRtbCIsIm1lc3NhZ2UiLCJzdGF0dXMiLCJqc29uIiwic3VjY2VzcyIsImVyciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/contact.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/contact.js"));
module.exports = __webpack_exports__;

})();